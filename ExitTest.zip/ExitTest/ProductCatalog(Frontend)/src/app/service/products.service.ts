import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  private baseUrl: string = 'http://localhost:8082/authenticate';

  constructor(private http: HttpClient) {}

  // userlogin(data: any) {
  //   return this.http.post(`${this.baseUrl}/authenticate`, data);
  // }

  getAllProducts() {
    return this.http.get(`${'http://localhost:8082'}/product/all`);
  }

  getSearchedProduct(data: any) {
    return this.http.get(`${'http://localhost:8082'}/product/{data}`);
  }

  register(data: any) {
    return this.http.post(`${'http://localhost:8082'}/add`, data);
  }

  generateToken(credentials: any) {
    return this.http.post(this.baseUrl, credentials);
  }

  loginUser(token: any) {
    localStorage.setItem('token', token);
  }

  isLoggedin() {
    let token = localStorage.getItem('token');
    if (token == undefined || token === '' || token == null) {
      return false;
    } else {
      return true;
    }
  }
  logout() {
    localStorage.removeItem('token');
    return true;
  }
  getToken() {
    return localStorage.getItem('token');
  }
}
