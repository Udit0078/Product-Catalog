import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { BrandFilterComponent } from './Components/brand-filter/brand-filter.component';
import { CardViewComponent } from './Components/allProducts/card-view.component';
import { PriceFilterComponent } from './Components/price-filter/price-filter.component';
import { ProductSearchComponent } from './Components/product-search/product-search.component';
import { UserRegistrationComponent } from './Components/user-registration/user-registration.component';
import { UserloginComponent } from './Components/userlogin/userlogin.component';

const routes: Routes = [
{
  path:"",
  component:CardViewComponent,
  pathMatch:"full"
},
{
  path: "login",
  component:UserloginComponent,
  pathMatch:"full"
},
{
  path: "register",
  component:UserRegistrationComponent,
  pathMatch:"full",
  
}
,
{
  path: "productDetails",
  component:ProductSearchComponent,
  pathMatch:"full",
  canActivate:[AuthGuard]
}
,
{
  path: "brand",
  component:BrandFilterComponent,
  pathMatch:"full",
  canActivate:[AuthGuard]
},
{
  path: "price",
  component:PriceFilterComponent,
  pathMatch:"full",
  canActivate:[AuthGuard]
}




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
