import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductsService } from 'src/app/service/products.service';

@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css'],
})
export class ProductSearchComponent implements OnInit {
  lis: any = [];
  code: any = '';
  zipcode = {
    pin: '',
  };

  constructor(
    private service: ProductsService,
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.searchProduct();
  }
  searchProduct() {
    this.route.queryParams.subscribe((response: any) => {
      this.code = response.code;
      let url = 'http://localhost:8082/product/' + this.code;
      console.log(url);

      this.http.get(url).subscribe((response: any) => {
        console.log(response);

        this.lis = response;
      });
    });
  }

  productDelivery() {
    let url =
      'http://localhost:8082/product/' + this.code + '/' + this.zipcode.pin;
    console.log(url);

    this.http.get(url).subscribe((response: any) => {
      console.log(response);
      if (response == null)
        alert('Sorry product is not available at your pincode');
      else alert('Your product will be delivered within 5 days');
      //this.lis=response;
    });
  }
}
