import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductsService } from 'src/app/service/products.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css'],
})
export class UserloginComponent implements OnInit {
  data = {
    email: '',
    password: '',
  };

  constructor(private user: ProductsService, private router: Router) {}

  ngOnInit(): void {}

  userLogin() {
    this.user.generateToken(this.data).subscribe((response: any) => {
      console.log(response.jwt);

      this.user.loginUser(response.jwt);
      // console.log(response.);
      // console.log(response);

      window.location.href = '/';
    });
    // this.user.(this.data).subscribe(
    //   response=>{
    //     if(response)
    //     {
    //       console.log(response);

    //       this.router.navigate(['/']);
    //     }
    //     else{
    //       console.log("error");
    //      // this.msg="Incorrect Username or Password";

    //     }
    //   }
    // )
  }
}
