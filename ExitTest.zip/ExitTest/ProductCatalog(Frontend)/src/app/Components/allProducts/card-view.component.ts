import { Options } from '@angular-slider/ngx-slider/options';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductsService } from 'src/app/service/products.service';

@Component({
  selector: 'app-card-view',
  templateUrl: './card-view.component.html',
  styleUrls: ['./card-view.component.css'],
})
export class CardViewComponent implements OnInit {
  minValue: number = 20;
  maxValue: number = 80;
  options: Options = {
    floor: 0,
    ceil: 100,
    step: 10,
    showTicks: true,
  };

  price = {
    min: '',
    max: '',
  };

  lis: any = [];
  ex: any = '';
  public loggedIn = false;

  data = {
    Adidas: 'Adidas',
    Puma: 'Puma',
    Nike: 'Nike',
    Reebok: 'Reebok',
  };

  constructor(
    private service: ProductsService,
    private router: Router,
    private route: ActivatedRoute,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.loggedIn = this.service.isLoggedin();

    this.route.queryParams.subscribe((res: any) => {
      this.ex = res.ex;
      console.log(this.ex);

      if (this.ex == null) {
        this.service.getAllProducts().subscribe((response) => {
          console.log(response);

          this.lis = response;
        });
      } else {
     
        let url = 'http://localhost:8082/product/' + this.ex;
        this.http.get(url).subscribe((response) => {
          console.log(response);

          this.lis = response;
       
        });
      }
    });
    console.log(this.ex);
  }

  onValue(event: any) {
    console.log(event.value);
    this.router.navigate(
      ['/brand'],

      { queryParams: { data: this.ex, brand: event.value } }
    );
  }

  onSubmit() {
    console.log(this.price);

    this.router.navigate(
      ['/price'],

      {
        queryParams: {
          data: this.ex,
          min: this.price.min,
          max: this.price.max,
        },
      }
    );
  }
}
