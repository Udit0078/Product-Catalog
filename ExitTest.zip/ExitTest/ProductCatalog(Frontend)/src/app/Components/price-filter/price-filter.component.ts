import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-price-filter',
  templateUrl: './price-filter.component.html',
  styleUrls: ['./price-filter.component.css'],
})
export class PriceFilterComponent implements OnInit {
  list: any = [];
  ulist: any = [];
  param: any;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.sortPrice();
  }

  sortPrice() {
    // var slider= new Slider("#slider1");
    // slider.on("slide", function(slideEvt) {
    //   var min = slider.options.min,
    //       max = slider.options.max
    //       console.log(min);
    //       console.log(max);
    //       le1 = slideEvt[0] - min;
    //       le2 = slideEvt[1] - le1;
    //       le3 = max - le1 - le2;
    // });

    this.route.queryParams.subscribe((value: any) => {
      console.log(value.brand);

      //  this.brand=value.brand;

      this.param = value.data;

      // console.log(this.brand);

      let url = 'http://localhost:8082/product/' + this.param;

      console.log(this.param);

      this.http.get(url).subscribe(
        (response) => {
          console.log(response);

          if (response == null) {
            alert('No such product exists!');

            window.location.href = '/';
          }

          this.list.push(response);

          console.log('hello' + Object.entries(this.list)[0][1]);

          this.list = Object.entries(this.list)[0][1];

          for (let i = 0; i < this.list.length; i++) {
            console.log(this.list[i].price);
            if (
              value.min <= this.list[i].price &&
              value.max >= this.list[i].price
            ) {
              console.log(this.list[i].price);

              this.ulist.push(this.list[i]);
            }
          }

          console.log(this.ulist);
        },
        (error) => {
          alert('No such product exists!');
        }
      );
    });
  }
}
