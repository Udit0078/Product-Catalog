import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductsService } from 'src/app/service/products.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css'],
})
export class UserRegistrationComponent implements OnInit {
  data = {
    email: '',
    firstName: '',
    lastName: '',
    password: '',
  };
  passwords = {
    pass: '',
    confirmPass: '',
  };

  constructor(private user: ProductsService, private router: Router) {}

  ngOnInit(): void {}

  addUser() {
    if (this.passwords.pass != this.passwords.confirmPass) {
      alert('Passwords are not same');
    } else {
      this.data.password = this.passwords.confirmPass;
      this.user.register(this.data).subscribe((response) => {
        if (response) {
          console.log(response);

          this.router.navigate(['/login']);
        } else {
          console.log('error');
          //this.msg="Incorrect Username or Password";
        }
      });
    }
  }
}
