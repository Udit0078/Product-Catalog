import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductsService } from 'src/app/service/products.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  constructor(private service: ProductsService, private router: Router) {}

  public loggedIn = false;

  data = {
    product: '',
  };

  ngOnInit(): void {
    this.loggedIn = this.service.isLoggedin();
  }

  getProduct() {
    console.log('hello world');

    this.router.navigate(['/'], { queryParams: { ex: this.data.product } });
  }
  logoutUser() {
    this.service.logout();
    location.reload();
  }
}
