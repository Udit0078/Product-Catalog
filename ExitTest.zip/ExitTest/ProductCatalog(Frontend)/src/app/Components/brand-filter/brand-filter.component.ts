import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductsService } from 'src/app/service/products.service';

@Component({
  selector: 'app-brand-filter',
  templateUrl: './brand-filter.component.html',
  styleUrls: ['./brand-filter.component.css'],
})
export class BrandFilterComponent implements OnInit {
  brand: any = '';
  param: any;

  list: any = [];

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private service: ProductsService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((value: any) => {
      console.log(value.brand);

      this.brand = value.brand;

      this.param = value.data;

      console.log(this.brand);

      let url = 'http://localhost:8082/product/' + this.param;

      console.log(this.param);

      this.http.get(url).subscribe(
        (response) => {
          console.log(response);

          if (response == null) {
            alert('No such product exists!');

            window.location.href = '/';
          }

          this.list.push(response);

          console.log('hello' + Object.entries(this.list)[0][1]);

          this.list = Object.entries(this.list)[0][1];
        },
        (error) => {
          alert('No such product exists!');
        }
      );
    });
  }
}
