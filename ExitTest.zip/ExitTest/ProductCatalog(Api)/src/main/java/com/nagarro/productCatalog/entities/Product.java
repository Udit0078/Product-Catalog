package com.nagarro.productCatalog.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Product {
	
	private String brand;
	private String name;
	@Id
	@Column(name="product_code")
	private String  productCode;
	private double price;
	private String imageUrl;
	
	@ManyToMany(fetch=FetchType.LAZY,
			cascade= {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.DETACH,CascadeType.REFRESH})
	@JoinTable(
			name="product_zipcodes",
			joinColumns=  @JoinColumn(name="product_code"),
			inverseJoinColumns=@JoinColumn(name="zip_id")
			
			)
	 @JsonManagedReference
	private List<ZipCodes> ziplist;
	
	public Product(String brand, String name, String productCode, double price) {
		super();
		this.brand = brand;
		this.name = name;
		this.productCode = productCode;
		this.price = price;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public List<ZipCodes> getZiplist() {
		return ziplist;
	}
	public void setZiplist(List<ZipCodes> ziplist) {
		this.ziplist = ziplist;
	}

	
	

}
