package com.nagarro.productCatalog.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ZipCodes extends JpaRepository<com.nagarro.productCatalog.entities.ZipCodes,Integer> {

	
	
}
