package com.nagarro.productCatalog.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagarro.productCatalog.entities.Users;

@Repository
public interface User extends JpaRepository<Users,String> {
	
	Users findByemail(String S);
}
