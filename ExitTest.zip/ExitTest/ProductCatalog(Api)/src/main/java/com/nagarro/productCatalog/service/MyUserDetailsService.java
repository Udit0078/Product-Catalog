package com.nagarro.productCatalog.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.nagarro.productCatalog.entities.Users;

@Service
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	com.nagarro.productCatalog.dao.User user;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
	{
		// TODO Auto-generated method stub
		//System.out.println(username);
		Users obj=user.findByemail(username);
		System.out.println(obj.getPassword());
		
	//return new User("udit","tidu",new ArrayList<>());
		return new User(username,obj.getPassword(),new ArrayList<>());
	}
	

}
