package com.nagarro.productCatalog.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface Product extends JpaRepository<com.nagarro.productCatalog.entities.Product, Integer> {
	
		List<com.nagarro.productCatalog.entities.Product> findByproductCode(String S);
		List<com.nagarro.productCatalog.entities.Product> findByname(String S);
		List<com.nagarro.productCatalog.entities.Product> findAllBybrand(String S);
}
