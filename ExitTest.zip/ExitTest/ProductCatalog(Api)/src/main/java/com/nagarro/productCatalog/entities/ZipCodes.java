package com.nagarro.productCatalog.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class ZipCodes {
	
	@Id
	@Column(name="zip_id")
	private Integer pincode;
	
	@ManyToMany(fetch=FetchType.LAZY,
			cascade= {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.DETACH,CascadeType.REFRESH})
	@JoinTable(
			name="product_zipcodes",
			joinColumns=  @JoinColumn(name="zip_id"),
			inverseJoinColumns=@JoinColumn(name="product_code")
			
			)
	@JsonBackReference
	private List<Product> products;
	
	private String pinId;
	
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	public void addProduct(Product product)
	{
		if(products==null)
		{
			products=new ArrayList<>();
		}
		products.add(product);
	}
	public Integer getPincode() {
		return pincode;
	}
	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
	public String getZipId() {
		return pinId;
	}
	public void setZipId(String zipId) {
		this.pinId = zipId;
	}
	public ZipCodes() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ZipCodes [pincode=" + pincode + ", products=" + products + ", pinId=" + pinId + "]";
	}
	
	
	

}
