package com.nagarro.productCatalog.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.productCatalog.dao.ZipCodes;

import com.nagarro.productCatalog.dao.Product;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = "*")
@Component
public class ProductController {
	
	@Autowired
	Product products;
	
	@Autowired
	ZipCodes zip;

	@GetMapping("/{id}/{pinCode}")
	public List<com.nagarro.productCatalog.entities.Product> getAvailablity(@PathVariable("id") String productCode, @PathVariable("pinCode") Integer pinCode )
	{
		List<com.nagarro.productCatalog.entities.Product> product = products.findByproductCode(productCode);
		for(com.nagarro.productCatalog.entities.ZipCodes x:product.get(0).getZiplist())
		{
			System.out.println(x.getPincode()+ " "+ pinCode);
			if(x.getPincode().equals(pinCode))
			{
				return products.findByproductCode(productCode); 
			}
		}
		
		return null;
			
		
	}
	
	@GetMapping("/all")
	public List<com.nagarro.productCatalog.entities.Product> getAllProducts()
	{
		return products.findAll();
	}
	
	
	@GetMapping("/{product}")
	public List<com.nagarro.productCatalog.entities.Product> getProducts(@PathVariable("product") String product )
	{
		
		
		if(!products.findByname(product).isEmpty()) {
		
		
			return products.findByname(product);
		}
		 if(!products.findAllBybrand(product).isEmpty())
		{
			return products.findAllBybrand(product);
		}
		 if(!products.findByproductCode(product).isEmpty())
		{
			System.out.println("hello");
			return products.findByproductCode(product);
		}
		else {
		
			return null;
		}
			
			
	}
	
	
}
